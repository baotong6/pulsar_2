import numpy as np
def xyz_to_BLH(X,Y,Z):
    a = 6378137
    f=1.0/298.257223563
    b=a*(1-f)
    e1=(a**2-b**2)**0.5/a
    e2=(a**2-b**2)**0.5/b
    theta=np.arctan(Z*a/(b*(X**2+Y**2)**0.5))
    L=np.arctan(Y/X)
    B=np.arctan((Z+e2**2*b*np.sin(theta)**3)/((X**2+Y**2)**0.5-e1**2*a*np.cos(theta)**3))
    N = a / (1 - e1 ** 2 * np.sin(B) ** 2) ** 0.5
    H=(X**2+Y**2)**0.5/np.cos(B)-N

    L = L * 180 / np.pi
    B = B * 180 / np.pi

    return [L,B,H]

#print xyz_to_BLH(2659244.2,4816584.0,4106395.2)
